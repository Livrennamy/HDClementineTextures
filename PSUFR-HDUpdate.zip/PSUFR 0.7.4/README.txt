PSUFR Version 0.7.4 is PSUFR Version 0.7.3 with Hotfix patch applied.

NOTE: HOTFIX PATCH HAS ALREADY BEEN APPLIED FOR THIS DOWNLOAD. THE FOLLOWING IS FOR YOUR INFORMATION REGARDING UPDATES SINCE LATEST RELEASE. IF YOU ALREADY HAVE VERSION 0.7.3 DOWNLOADED AND INSTALLED, THEN FOLLOW PLUVIO'S INSTRUCTIONS BELOW TO APPLY THE PATCH YOURSELF.

Pluvio — 05/10/2022
https://drive.google.com/file/d/1x4CfMavXdGBzgkYu8P0rUYpKyAYbWnoY/view?usp=sharing
Okay here's a quick fix, I removed the update check so it should boot up fine now with no weird extra lag.
You just have to replace your current PSURFR.exe (0.7.3) with the one inside of the archive and then inside of your preexisting PSUFR_config.txt, paste the following in between "//Show Players (Mission)//" and "//Health Size (Players)//"

//Show Character Info (Mission_Players)//
1

(or 0 if you want it off)

Or if you don't mind setting up your options again, you can just replace your old PSUFR_config.txt with the one inside of the archive as well.
I'll have to figure out another way to show updates inside of the program since I can't use Pastebin anymore, but I think this should work until I make a better update.
Also there were some minor changes to Show Players (Mission) that I haven't tested yet, so I hope it's not a buggy mess.